namespace _63010584_Web.Models;

public class inputTextModel
{
    public string? Fname { get; set; }
    public string? Lname { get; set; }
    public string? Email { get; set; }
    public string? Tallparis { get; set; }
    public string? Textarea { get; set; }
}

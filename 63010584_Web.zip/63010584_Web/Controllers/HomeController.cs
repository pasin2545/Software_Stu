﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using _63010584_Web.Models;

namespace _63010584_Web.Controllers;


public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
 
    
    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult IndexHandle(string fname, string lname, string email,string tallparis, string textarea)
    {
        inputTextModel tmp = new inputTextModel();
        tmp.Fname = fname;
        tmp.Lname = lname;
        tmp.Email = email;
        tmp.Tallparis = tallparis;
        tmp.Textarea = textarea;
        return View(tmp);
    }

}

﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using _63010656_MVC.Models;

namespace _63010656_MVC.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Privacy(string fname,string lname,string email,string tall,string reason)
    {
        InputTextModel ans = new InputTextModel();
        ans.Fname = fname;
        ans.Lname = lname;
        ans.Email = email;
        ans.Tall = tall;
        ans.Reason = reason;

        return View(ans);
    }
}

namespace _63010656_MVC.Models;

public class InputTextModel
{
    public string? Fname { get;set; }
    public string? Lname { get;set; }
    public string? Email { get;set; }
    public string? Tall { get;set; }
    public string? Reason { get;set; }
}

